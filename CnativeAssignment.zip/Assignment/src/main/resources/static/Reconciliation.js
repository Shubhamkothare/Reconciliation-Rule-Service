function addService(){
	alert("Add successfully !!!")
}


 function AddRuleCondition(){
	 $("#data").removeClass("hidden");
}
